import os
from textbase import bot, Message
from textbase.models import OpenAI
from typing import List
import requests
import re

# Load your OpenAI API key
OpenAI.api_key = "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"
# or from environment variable:
# OpenAI.api_key = os.getenv("OPENAI_API_KEY")

# Define your Alpha Vantage API key (store it securely, don't hardcode here)
ALPHA_VANTAGE_API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")

# Prompt for GPT-3.5 Turbo
SYSTEM_PROMPT = """You are chatting with an AI. There are no specific prefixes for responses, so you can ask or talk about anything you like.
You will respond in a natural, conversational manner. Feel free to start the conversation with any question or topic, and let's have a pleasant chat!
"""

@bot()
def on_message(message_history: List[Message], state: dict = None):
    user_message = message_history[-1].content.lower()

    if "stock price" in user_message:
        stock_symbol = extract_stock_symbol(user_message)
        if stock_symbol:
            stock_price = get_stock_price(stock_symbol)
            if stock_price is not None:
                bot_response = f"The current stock price of {stock_symbol} is ${stock_price:.2f}."
            else:
                bot_response = f"Sorry, I couldn't retrieve the stock price for {stock_symbol} at the moment."
        else:
            bot_response = "Please specify a valid stock symbol."

    # Generate GPT-3.5 Turbo response
    gpt_response = OpenAI.generate(
        system_prompt=SYSTEM_PROMPT,
        message_history=message_history,  # Assuming history is the list of user messages
        model="gpt-3.5-turbo",
    )

    response = {
        "data": {
            "messages": [
                {
                    "data_type": "STRING",
                    "value": gpt_response
                },
                {
                    "data_type": "STRING",
                    "value": bot_response
                }
            ],
            "state": state
        },
        "errors": [
            {
                "message": ""
            }
        ]
    }

    return {
        "status_code": 200,
        "response": response
    }


def extract_stock_symbol(user_message):
    # Define a regular expression pattern to match stock symbols (e.g., AAPL, GOOGL)
    pattern = r'\b[A-Z]{1,5}\b'  # Matches one to five uppercase letters surrounded by word boundaries

    # Use re.findall to find all matches in the user's message
    stock_symbols = re.findall(pattern, user_message)

    # Check if any stock symbols were found
    if stock_symbols:
        # Return a list of unique stock symbols found in the message
        return list(set(stock_symbols))
    else:
        # If no stock symbols were found, return None
        return None


def get_stock_price(stock_symbol):
    try:
        endpoint = f"https://www.alphavantage.co/query"
        params = {
            "function": "TIME_SERIES_INTRADAY",
            "symbol": stock_symbol,
            "interval": "1min",  # Adjust the interval as needed (e.g., "1d" for daily)
            "apikey": ALPHA_VANTAGE_API_KEY,
        }
        response = requests.get(endpoint, params=params)
        if response.status_code == 200:
            data = response.json()
            # Check if the API response contains time series data
            if "Time Series (1min)" in data:
                latest_close = data["Time Series (1min)"].get(list(data["Time Series (1min)"].keys())[0], {}).get("4. close")
                if latest_close:
                    return float(latest_close)
        return None
    except Exception as e:
        print(f"Error fetching stock price: {e}")
        return None
